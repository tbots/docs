echo "Sceleton : " `pwd`'/'`basename "$0"`
export DISHOME=`pwd`
$DISHOME/scripts/dwh/caller.bash
