echo "Sceleton : " `pwd`'/'`basename "$0"`
echo "Hacked dwh_generate_views"
#!/bin/bash
. /etc/profile.d/disforce-env.sh
. /etc/profile.d/oracle-client.sh

#set variables needed in the child scripts
IniFile=$1
TargetDate=$2

#check if ini file was provided
if [ -z $IniFile ];
then
	echo "Error : Ini file was not provided as first program argument"
	exit 1
fi

#check if ini file exists
if [ ! -r $IniFile ];
then
	echo "Error : Ini file ($IniFile) does not exist"
	exit 1
fi 

#check if TargetDate was provided as a parameter
if [ -z $TargetDate ];
then
	echo "Error : TargetDate was not provided as second program argument"
	exit 1
fi

source $IniFile

outputFile=/tmp/dwh_generate_views_$$.tmp.out

#check if TargetDate argument was in a valid format
echo "select to_timestamp('$TargetDate', 'YYYYMMDD') from dual;" \
| sqlplus -silent $DB_USER/$DB_PASSWD@$DB_SERVER &> $outputFile
if [ `grep -i error $outputFile | wc -l` -ne 0 ];
then
	echo "Error : TargetDate program argument not in the valid format YYYYMMDD"
	rm -f $outputFile
	exit 1
fi





echo "`date "+%Y-%m-%d %H:%M:%S"` : Generate the views"

operationViewList=/tmp/operationViewList



echo "`date "+%Y-%m-%d %H:%M:%S"` : Move data from views downstream"

echo "begin
  pck_applog.MoveData('$TargetDate');
end;
/" | sqlplus -silent $DB_USER/$DB_PASSWD@$DB_SERVER &> $outputFile
if [ `grep -i error $outputFile | wc -l` -ne 0 ];
then
	echo "Error : execution pck_applog.movedata pl/sql function. For more info check $outputFile"
	exit 1
fi

export TargetDate
#generate the summaries
echo "`date "+%Y-%m-%d %H:%M:%S"` : Generating summaries"
$DISHOME/scripts/dwh/gen_summary_mention_acquisition.bash $IniFile
$DISHOME/scripts/dwh/gen_summary_applog_usage.bash $IniFile

#final_search/result for backwards compatibility
echo "`date "+%Y-%m-%d %H:%M:%S"` : Moving data to final_search/result"
#final_search
$DISHOME/scripts/dwh/gen_final_search_applog_eshopclick.bash $IniFile


echo "update dwh_retention set max_date = to_date('$TargetDate', 'YYYYMMDD') + 1, mod_timestamp = sysdate 
where table_name = 'FINAL_SEARCH' and nvl(max_date, to_date('19700101', 'YYYYMMDD')) < to_date('$TargetDate', 'YYYYMMDD') + 1;
update dwh_retention set max_date = to_date('$TargetDate', 'YYYYMMDD') + 1, mod_timestamp = sysdate 
where table_name = 'FINAL_RESULT' and nvl(max_date, to_date('19700101', 'YYYYMMDD')) < to_date('$TargetDate', 'YYYYMMDD') + 1;" \
 | sqlplus -silent $DB_USER/$DB_PASSWD@$DB_SERVER &> $outputFile
if [ `grep -i error $outputFile | wc -l` -ne 0 ];
then
        echo "Error : update dwh_retention for final_search/result. For more info check $outputFile"
        exit 1
fi

rm -f $outputFile

echo "`date "+%Y-%m-%d %H:%M:%S"` : Script End"
