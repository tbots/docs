echo "Sceleton : " `pwd`'/'`basename "$0"`
#!/bin/bash commented out
#. /etc/profile.d/disforce-env.sh
#. /etc/profile.d/oracle-client.sh

 

######################################################################
#   param  1  == MESSAGE
######################################################################
function logMessage
{
	if [ -z $log_file_name ]
	then
		echo "`date '+%Y-%m-%d %H:%M:%S'`|$1"
	else
		echo "`date '+%Y-%m-%d %H:%M:%S'`|$1" >> $log_file_name
	fi
}

######################################################################
#   param  1  == DIR_NAME
######################################################################
function validateDir
{
	# Verify that the directory exists
	if [ ! -d $1 ]
	then
		echo "Directory <$1> does not exist"
		exit 3
	fi
}

#added for sceleton purposes
mkdir -pv $HOME/logs/dwh



logMessage "Step 6 : Generate the Applog derived data"
$DISHOME/scripts/dwh/dwh_generate_views.bash $HOME/ini/dwh/common.ini `date "+%Y%m%d" -d "-1 day"` &> $HOME/logs/dwh/dwh_generate_views.`date "+%Y%m%d.%H%M%S"`.log

logMessage "Done"
